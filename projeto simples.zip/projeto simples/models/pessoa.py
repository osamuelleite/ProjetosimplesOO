import json
from typing import List, Optional

class Pessoa:
    def __init__(self, nome: str):
        self.nome = nome

class Medico(Pessoa):
    def __init__(self, nome: str, crm: str, especialidade: str):
        super().__init__(nome)
        self.crm = crm
        self.especialidade = especialidade
        self.pacientes: List[str] = []  # lista de emails dos pacientes

class Paciente(Pessoa):
    def __init__(self, nome: str, email: str, data_nascimento: str, doenca: str):
        super().__init__(nome)
        self.email = email
        self.data_nascimento = data_nascimento
        self.doenca = doenca
        self.medico_crm: Optional[str] = None
        self.prescricoes: List[str] = []
        self.info_extra: List[str] = []
