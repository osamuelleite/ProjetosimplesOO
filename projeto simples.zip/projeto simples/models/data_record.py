import json
import os
from typing import Dict, Any

class DataRecord:
    def __init__(self, login_path: str, users_path: str):
        self.login_path = login_path
        self.users_path = users_path
        os.makedirs(os.path.dirname(self.login_path), exist_ok=True)
        os.makedirs(os.path.dirname(self.users_path), exist_ok=True)
        if not os.path.exists(self.login_path):
            with open(self.login_path, 'w') as f:
                json.dump({}, f)
        if not os.path.exists(self.users_path):
            with open(self.users_path, 'w') as f:
                json.dump({}, f)

    def save_login(self, key: str, senha: str, tipo: str):
        logins = self._load_json(self.login_path)
        logins[key] = {'senha': senha, 'tipo': tipo}
        self._save_json(self.login_path, logins)

    def check_login(self, key: str, senha: str) -> str:
        logins = self._load_json(self.login_path)
        if key in logins and logins[key]['senha'] == senha:
            return logins[key]['tipo']
        return ''

    def save_user(self, key: str, data: Dict[str, Any]):
        users = self._load_json(self.users_path)
        users[key] = data
        self._save_json(self.users_path, users)

    def load_user(self, key: str) -> Dict[str, Any]:
        users = self._load_json(self.users_path)
        return users.get(key, {})

    def _load_json(self, path: str) -> Dict[str, Any]:
        with open(path, 'r') as f:
            return json.load(f)

    def _save_json(self, path: str, data: Dict[str, Any]):
        with open(path, 'w') as f:
            json.dump(data, f, indent=2)
