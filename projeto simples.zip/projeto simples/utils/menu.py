import os

def limpar_terminal():
    os.system('clear')

def print_menu(title, options):
    limpar_terminal()
    print(f'\n--- {title} ---')
    for i, opt in enumerate(options, 1):
        print(f'{i}. {opt}')
    print('0. Sair')
    return input('Escolha uma opção: ')
