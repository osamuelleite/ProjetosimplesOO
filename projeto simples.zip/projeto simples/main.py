from models.data_record import DataRecord
from controllers.medico_controller import MedicoController
from controllers.paciente_controller import PacienteController
from utils.menu import print_menu

LOGIN_PATH = 'data/logins.json'
USERS_PATH = 'data/users.json'

def main():
    data_record = DataRecord(LOGIN_PATH, USERS_PATH)
    medico_controller = MedicoController(data_record)
    paciente_controller = PacienteController(data_record)

    while True:
        opcao = print_menu('Med SYS, seu sistema médico eficiente!', [
            'Cadastrar Médico',
            'Cadastrar Paciente',
            'Login Médico',
            'Login Paciente'
        ])
        if opcao == '1':
            medico_controller.cadastrar_medico()
        elif opcao == '2':
            paciente_controller.cadastrar_paciente()
        elif opcao == '3':
            crm = medico_controller.login_medico()
            if crm:
                menu_medico(crm, medico_controller, data_record)
        elif opcao == '4':
            email = paciente_controller.login_paciente()
            if email:
                menu_paciente(email, paciente_controller, data_record)
        elif opcao == '0':
            print('Saindo...')
            break
        else:
            print('Opção inválida!')

def menu_medico(crm, medico_controller, data_record):
    while True:
        opcao = print_menu('Menu Médico', [
            'Prescrever medicamento para paciente',
            'Agendar consulta para paciente',
            'Adicionar paciente para acompanhamento',
            'Ver lista de pacientes do médico',
            'Ver todos os pacientes do sistema'
        ])
        if opcao == '1':
            medico_controller.prescrever_medicamento(crm)
        elif opcao == '2':
            medico_controller.agendar_consulta(crm)
        elif opcao == '3':
            medico_controller.adicionar_paciente(crm)
        elif opcao == '4':
            medico = data_record.load_user(crm)
            print('Pacientes:', medico.get('pacientes', []))
        elif opcao == '5':
            medico_controller.listar_todos_pacientes()
        elif opcao == '0':
            break
        else:
            print('Opção inválida!')

def menu_paciente(email, paciente_controller, data_record):
    while True:
        opcao = print_menu('Menu Paciente', [
            'Ver médico responsável',
            'Ver prescrições',
            'Adicionar informação relevante para o médico',
            'Ver consultas agendadas'
        ])
        if opcao == '1':
            paciente_controller.visualizar_medico_responsavel(email)
        elif opcao == '2':
            paciente_controller.visualizar_prescricoes(email)
        elif opcao == '3':
            paciente_controller.adicionar_info_relevante(email)
        elif opcao == '4':
            paciente_controller.visualizar_consultas(email)
        elif opcao == '0':
            break
        else:
            print('Opção inválida!')

if __name__ == '__main__':
    main()
