from models.pessoa import Paciente
from models.data_record import DataRecord

class PacienteController:
    def __init__(self, data_record: DataRecord):
        self.data_record = data_record

    def cadastrar_paciente(self):
        nome = input('Nome do paciente: ')
        email = input('Email: ')
        data_nascimento = input('Data de nascimento: ')
        doenca = input('Doença: ')
        senha = input('Senha: ')
        paciente = Paciente(nome, email, data_nascimento, doenca)
        self.data_record.save_login(email, senha, 'paciente')
        self.data_record.save_user(email, {
            'nome': nome,
            'email': email,
            'data_nascimento': data_nascimento,
            'doenca': doenca,
            'medico_crm': None,
            'prescricoes': [],
            'info_extra': [],
            'consultas': []
        })
        print('Paciente cadastrado com sucesso!')

    def login_paciente(self):
        email = input('Email: ')
        senha = input('Senha: ')
        tipo = self.data_record.check_login(email, senha)
        if tipo == 'paciente':
            print('Login realizado com sucesso!')
            return email
        else:
            print('Email ou senha inválidos.')
            return None

    def visualizar_prescricoes(self, email):
        paciente = self.data_record.load_user(email)
        prescricoes = paciente.get('prescricoes', [])
        if prescricoes:
            print('Prescrições:')
            for i, p in enumerate(prescricoes, 1):
                print(f'{i}. {p}')
        else:
            print('Nenhuma prescrição encontrada.')
        input('\nPressione ENTER para continuar...')

    def visualizar_medico_responsavel(self, email):
        paciente = self.data_record.load_user(email)
        medico_crm = paciente.get('medico_crm')
        if medico_crm:
            print(f'Médico responsável: {medico_crm}')
        else:
            print('Nenhum médico responsável cadastrado.')
        input('\nPressione ENTER para continuar...')

    def adicionar_info_relevante(self, email):
        info = input('Digite a informação relevante para seu médico: ')
        paciente = self.data_record.load_user(email)
        paciente.setdefault('info_extra', []).append(info)
        self.data_record.save_user(email, paciente)
        print('Informação adicionada com sucesso!')
        input('\nPressione ENTER para continuar...')

    def visualizar_consultas(self, email):
        paciente = self.data_record.load_user(email)
        consultas = paciente.get('consultas', [])
        if consultas:
            print('Consultas agendadas:')
            for c in consultas:
                print(f"Data: {c['data']} - Médico CRM: {c['medico_crm']}")
        else:
            print('Nenhuma consulta agendada.')
        input('\nPressione ENTER para continuar...')
